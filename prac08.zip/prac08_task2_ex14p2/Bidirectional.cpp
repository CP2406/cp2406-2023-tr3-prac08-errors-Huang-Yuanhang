import <iostream>;
import <fstream>;
import <string>;
import <string_view>;
import <format>;
import <exception>;

using namespace std;


void changeNumberForID(string_view filename, int id, string_view newNumber);

int main()
{
	try {
		changeNumberForID("data.txt", 263, "415-555-3333");
	} catch (const exception& caughtException) {
		cerr << caughtException.what() << endl;
	}
}

void changeNumberForID(string_view filename, int id, string_view newNumber)
{
	fstream ioData{ filename.data() };
	if (!ioData) {
		throw runtime_error{ format("Error while opening file {}.", filename.data()) };
	}

	while (ioData) {
		int idRead;
		ioData >> idRead;
		if (!ioData)
			break;


		if (idRead == id) {
			ioData.seekp(ioData.tellg());
			if (!ioData) {
				throw runtime_error{ "Failed to seek to the proper position in the output stream." };
			}
	
			ioData << " " << newNumber;
			if (!ioData) {
				throw runtime_error{ "Failed to write to the output stream." };
			}
			break;
		}

	
		string number;
		ioData >> number;
		if (!ioData) {
			throw runtime_error{ "Failed to read next number from the input stream." };
		}
	}
}