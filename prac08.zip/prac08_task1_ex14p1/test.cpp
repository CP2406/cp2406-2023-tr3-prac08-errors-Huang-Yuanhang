import <iostream>;
import <exception>;
import <vector>;

using namespace std;

void verifyDataSize(const vector<int>& data)
{
    if (data.size() % 2 != 0)
		throw logic_error{ "Number of data points must be even." };
}

void processData(const vector<int>& data)
{

    try {
        verifyDataSize(data);
    } catch (const logic_error&) {

        cerr << "Invalid number of data points in dataset. Aborting." << endl;

        throw;
    }

    for (auto& value : data) {
        if (value < 0)
			throw domain_error{ "Negative datapoints not allowed." };
    }

}

int main()
{
    try {
        vector data{ 1, 2, 3, -5, 6, 9 };
        processData(data);

    } catch (const domain_error& caughtException) {
        cerr << "domain_error: " << caughtException.what() << endl;
    } catch (const logic_error& caughtException) {
        cerr << "logic_error: " << caughtException.what() << endl;
    }
}
